"""
Author: Aung Zin Paing
This is a TicTacToe Gui tkinter app
"""
from tkinter import *
from tkinter import messagebox

# Game logic module
class TicTacToe:
    def __init__(self):
        self.board = [' '] * 9
        self.current_player = 'X'

    #checks moves made
    def make_move(self, position):
        if self.board[position] == ' ':
            self.board[position] = self.current_player
            self.current_player = 'O' if self.current_player == 'X' else 'X'

    #checks winner
    def check_winner(self):
        # Check rows
        for i in range(0, 9, 3):
            if self.board[i] == self.board[i+1] == self.board[i+2] != ' ':
                return self.board[i]

        # Check columns
        for i in range(3):
            if self.board[i] == self.board[i+3] == self.board[i+6] != ' ':
                return self.board[i]

        # Check diagonals
        if self.board[0] == self.board[4] == self.board[8] != ' ':
            return self.board[0]

        if self.board[2] == self.board[4] == self.board[6] != ' ':
            return self.board[2]

        # Check for tie
        if ' ' not in self.board:
            return 'Tie'

        return None

# GUI module
class TicTacToeGUI:
    #This is for the title, and the label that shows each player's turn.
    def __init__(self, root):
        self.root = root
        self.root.title("Tic Tac Toe")
        self.game = TicTacToe()

        self.player_label = Label(self.root, text="Player: X")
        self.player_label.pack()

        self.board_frame = Frame(self.root)
        self.board_frame.pack()

        #This is for buttons and board
        self.buttons = []
        for i in range(9):
            button = Button(self.board_frame, text='', width=4, height=2, command=lambda pos=i: self.make_move(pos))
            button.grid(row=i//3, column=i%3)
            self.buttons.append(button)

        self.reset_button = Button(self.root, text="Reset", command=self.reset_game)
        self.reset_button.pack()

        self.quit_button = Button(self.root, text="Quit", command=self.root.destroy)
        self.quit_button.pack()

    #This will show the position on board
    def make_move(self, position):
        self.game.make_move(position)
        self.update_board()

        winner = self.game.check_winner()
        if winner:
            if winner == 'Tie':
                messagebox.showinfo("Game Over", "It's a tie!")
            else:
                messagebox.showinfo("Game Over", f"{winner} wins!")
            self.reset_game()

    #For reseting the game
    def reset_game(self):
        self.game = TicTacToe()
        self.update_board()

    def update_board(self):
        for i in range(9):
            self.buttons[i].config(text=self.game.board[i])
        self.player_label.config(text=f"Player: {self.game.current_player}")

# Entry point
if __name__ == '__main__':
    root = Tk()
    TicTacToeGUI(root)
    root.mainloop()
